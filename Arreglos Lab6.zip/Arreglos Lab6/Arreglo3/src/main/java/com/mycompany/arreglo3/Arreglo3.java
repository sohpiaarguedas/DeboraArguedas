/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglo3;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Arreglo3 {

    public static void main(String[] args) {
        int numeros[]=new int [20];
        int numCambiar=0;
        int numMayor=numeros[0];
        int numElegido=1;
        int posicionMenor=0;
        int buscarNum;
        int indiceBuscarNum = 0;
        
        
        for(int i = 0;i<numeros.length;i++){
            Random random;
            numeros[i]=(int)(Math.random()*250)+1;

            
        }
        
         for(int i = 0;i<numeros.length;i++){
         JOptionPane.showMessageDialog(null, "Los numeros son "+numeros[i]);
         }
         
         
         //Encontrar el numero mayor y menor
         for(int i = 0;i<numeros.length;i++){
         if(numeros[i]>numMayor){
             numMayor=numeros[i];
       
        if(posicionMenor<numeros[i]){
            posicionMenor=numeros[i];
        
        }
        }
         
        
          
         }
          buscarNum=Integer.parseInt(JOptionPane.showInputDialog("Digite el numero a buscar"));
          for(int i = 0;i<numeros.length;i++){
         if(buscarNum==numeros[i]){
             indiceBuscarNum=buscarNum;
         }
          
          
          }
          
          if(buscarNum==indiceBuscarNum){
          JOptionPane.showMessageDialog(null, "se encontro el numero");
          
          } else {
          JOptionPane.showMessageDialog(null, "No se encontro el numero");
          }
        
          
         
          JOptionPane.showMessageDialog(null,"El numero mayor es "+numMayor);
         JOptionPane.showMessageDialog(null,"El numero menor es "+posicionMenor);
        
         
        numElegido=Integer.parseInt(JOptionPane.showInputDialog("Elija una posicion a buscar entre el 0 y 19"));
        
        JOptionPane.showMessageDialog(null,"El numero de la posicion "+numElegido+" es "+numeros[numElegido]);
        
        numCambiar=Integer.parseInt(JOptionPane.showInputDialog("Digite la posicion a cambiar"));
        numeros[numCambiar]=Integer.parseInt(JOptionPane.showInputDialog("Digite el nuevo valor de la posicion"));
        JOptionPane.showMessageDialog(null,"La posicion "+numCambiar+" es "+ numeros[numCambiar]);
    
        }
    }

