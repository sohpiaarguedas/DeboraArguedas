/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglo1;

import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Arreglo1 {

    public static void main(String[] args) {
        
//         En una clase defina y cree un arreglo unidimensional de tipo double capaz de almacenar 10
//valores. Escriba además las sentencias necesarias para:
//a. Llenar el arreglo.
//b. Calcular e imprimir el promedio de los valores almacenados en el arreglo.
//c. Determinar cuántos valores son mayores que el promedio.
//d. Determinar cuáles valores son menores que el promedio.
//e. Mostrar los valores del arreglo.


    

    double arreglos[]=new double[10];
     double suma=0;
     double promedio=0;
     int valorMayores=0;
     String valoresMenores="";
     
     
    
    for(int indice=0;indice<arreglos.length;indice++){
        double valor= Double.parseDouble(JOptionPane.showInputDialog("Digite un valor"));
        
        
        
         arreglos[indice]=valor;
         
         suma+=arreglos[indice];
         
        
    }
 
       
        promedio=suma/arreglos.length;
         JOptionPane.showMessageDialog(null,"El promedio de los valores es de: "+promedio);
         
         
         for(int indice=0;indice<arreglos.length;indice++){
         if(arreglos[indice]>promedio){
             
        valorMayores++;   
         
            }
         }
         
         for(int indice=0;indice<arreglos.length;indice++){
         if(arreglos[indice]<promedio){
             
        valoresMenores+=arreglos[indice]+",";   
         
            }
         }
         
    
         for(int indice=0;indice<arreglos.length;indice++){
        JOptionPane.showMessageDialog(null,"Los valores son:" +arreglos[indice]);}
         
         
        JOptionPane.showMessageDialog(null,"Los valores menores que el promedio son:" +valoresMenores);
        JOptionPane.showMessageDialog(null,"La cantidad de valores mayores que el promedio son:" +valorMayores);
    }
}
