/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglo4;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class Arreglo4 {

    public static void main(String[] args) {
        int valoresA=0;
        int valoresB=0;
        int valoresC=0;
//a. Sumar el elemento uno del arregloA con el elemento uno del arregloB y así
//sucesivamente hasta 45, almacenar el resultado en un arregloC.
//b. Muestre los valores de los 3 arreglos.
    int arregloA[]=new int[45];
    int arregloB[]=new int[45];
    int arregloC[]=new int[45];
    Random random;
    
    for(int i=0;i<arregloA.length;i++){
        
        arregloA[i]=(int)(Math.random()*45)+1;
        valoresA=arregloA[i];
        JOptionPane.showMessageDialog(null,"Los numeros del arreglo A son: "+valoresA);
    }
    
    for(int i=0;i<arregloA.length;i++){
        arregloB[i]=(int)(Math.random()*45)+1;
        valoresB=arregloB[i];
        
        JOptionPane.showMessageDialog(null,"Los numeros del arreglo B son: "+valoresB);
         }
    for(int i=0;i<arregloC.length;i++){
     arregloC[i]= arregloA[i]+arregloB[i];
    valoresC=arregloC[i];
     JOptionPane.showMessageDialog(null,"Los numeros del arreglo C son: "+valoresC);
    }
    
    
    }//fin del main
    
    
}//fin del class
