/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.matriz;

import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */public class PrincipalMenu {

     public static void main(String[] args){
        
        Matriz pruebaMatriz = new Matriz();
        PrincipalMenu menu = new PrincipalMenu();
        menu.menuMatriz(pruebaMatriz);
    }

    public void menuMatriz(Matriz pruebaMatriz) {

        int input;
        do {
            input = Integer.parseInt(JOptionPane.showInputDialog("**************** Menu *****************"
                    + "1. Llenar el arreglo bidimensional de manera aleatoria.\n"
                    + "2. Agregar un valor en un espacio específico del arreglo\n"
                    + "3. Imprimir todos los valores el arreglo bidimensional.\n"
                    + "4. Obtener el promedio de una fila especifica.\n"
                    + "5. Obtener el promedio de una columna especifica\n"
                    + "6. Imprimir los valores de una fila en específico del arreglo bidimensional.\n"
                    + "7. Imprimir los valores de una columna en específico del arreglo\n"
                    + "bidimensional. Imprimir los valores de la diagonal principal de izquierda\n"
                    + "a derecha.\n"
                    + "8. Imprimir los valores de la diagonal secundaria de derecha a izquierda.\n"
                    + "9. Imprimir los valores de la diagonal principal de derecha a izquierda.\n"
                    + "10. Imprimir los valores de la diagonal secundaria de izquierda a derecha.\n"
                    + "11. Calcular promedio.\n"
                    + "12. Salir."));

            switch (input){
                case 1:
                    pruebaMatriz.llenarArreglo();
                    JOptionPane.showMessageDialog(null, "Se ha llenado la matriz");
                    break;

                case 2:
                    int columna = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la columna:"));
                    int fila = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la fila:"));
                    int valor = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor:"));
                    pruebaMatriz.matriz[fila][columna] = valor;
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null, pruebaMatriz.toString());
                    break;

                case 4:
                    fila = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la fila:"));
                    JOptionPane.showMessageDialog(null, "El promedio de la fila es: " + pruebaMatriz.getPromedioFila(fila));
                    break;

                case 5:
                    columna = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la columna:"));
                    JOptionPane.showMessageDialog(null, "El promedio de la columna es: " + pruebaMatriz.getPromedioColumna(columna));
                    break;

                case 6:
                    fila = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la fila:"));
                    JOptionPane.showMessageDialog(null, pruebaMatriz.getFila(fila));
                    break;

                case 7:
                    columna = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la columna:"));
                    JOptionPane.showMessageDialog(null, pruebaMatriz.getColumna(columna));
                    break;

                case 8:
                    JOptionPane.showMessageDialog(null, pruebaMatriz.getDiagonalSecundariaIzquierdaDerecha());
                    break;

                case 9:
                    JOptionPane.showMessageDialog(null, pruebaMatriz.getDiagonalPrincipalDerechaIzquierda());
                    break;

                case 10:
                    JOptionPane.showMessageDialog(null, pruebaMatriz.getDiagonalSecundariaIzquierdaDerecha());
                    break;

                case 11:
                    JOptionPane.showMessageDialog(null, pruebaMatriz.getPromedioT());
                    break;

                case 12:
                    JOptionPane.showMessageDialog(null, "saliendo...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Seleccione una opcion valida");
                    break;
            } // fin del switch

        } while (input!=12);

    } // fin de menu
}
