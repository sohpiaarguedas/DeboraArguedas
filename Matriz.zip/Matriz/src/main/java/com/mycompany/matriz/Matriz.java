/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.matriz;

/**
 *
 * @author Usuario
 */
public class Matriz {

    int matriz[][];

    public Matriz() {
        matriz = new int[4][4]; // 4x4
    }

    public Matriz(int filas, int columnas) {
        matriz = new int[filas][columnas]; // filas y columnas
    }

    public void llenarArreglo() {
        for (int fila = 0; fila < matriz.length; fila++) {
            for (int columna = 0; columna < matriz[fila].length; columna++) {
                matriz[fila][columna] = (int) (Math.random() * 100 + 1);
            }
        }
    }

    public String toString() {
        String datos = "Los datos del arreglo son \n";
        for (int fila = 0; fila < matriz.length; fila++) {
            for (int columna = 0; columna < matriz[fila].length; columna++) {
                datos += matriz[fila][columna] + " "; // acumula los valores de la fila
            }
            datos += "\n"; // cambio de fila
        }
        return datos;
    }

    public String getFila(int fila) {
        String datos = "Los datos de la fila son: \n";
        for (int columna = 0; columna < matriz[fila].length; columna++) {
            datos += matriz[fila][columna] + "\t";
        }
        return datos;
    }

    public String getColumna(int columna) {
        String datos = "Los datos de la columna son: \n";
        for (int fila = 0; fila < matriz.length; fila++) {
            datos += matriz[fila][columna] + "\t";
        }
        return datos;
    }

    public int getSumaFila(int fila) {
        int sumaF = 0;
        for (int columna = 0; columna < matriz[fila].length; columna++) {
            sumaF += matriz[fila][columna];
        }
        return sumaF;
    }

    public int getSumaColumna(int columna) {
        int sumaC = 0;
        for (int fila = 0; fila < matriz.length; fila++) {
            sumaC += matriz[fila][columna];
        }
        return sumaC;
    }

    public int getPromedioFila(int fila) {
        
        return getSumaFila(fila) / matriz[fila].length;

    }
public int getPromedioColumna(int columna) {
       return getSumaColumna(columna)/matriz.length;

    }
   

    public int getSuma(int fila) {
        int suma = 0;

        for (fila = 0; fila < matriz.length; fila++) {
            suma += getSumaFila(fila);
        }
        return suma;
    }

    public String getPromedioT() {
    int medidas = matriz.length * matriz[0].length;
    int promedioT = getSuma() / medidas;
    return "El promedio es de: "+promedioT;
}

    public String getDiagonalPrincipalIzquierdaDerecha() {


        String diagonalPrincipalIzquierdaDerecha = "Los valores de la diagonal principal izquierda a derecha son: ";
        String espacio = "";
        for (int posicion = 0; posicion < matriz.length; posicion++) {
            diagonalPrincipalIzquierdaDerecha += espacio + matriz[posicion][posicion] + "\n";
            espacio += "\t";
        }
        return diagonalPrincipalIzquierdaDerecha;
    }

    public String getDiagonalSecundariaIzquierdaDerecha() {

        String diagonalSecundariaIzquierdaDerecha = "Los valores de la diagonal secundaria izquierda a derecha son: ";
        for (int fila = 0; fila < matriz.length; fila++) {
            diagonalSecundariaIzquierdaDerecha += matriz[fila][matriz[fila].length - fila] + "\n";
        }
        return diagonalSecundariaIzquierdaDerecha;
    }

    public String getDiagonalPrincipalDerechaIzquierda() {

        String diagonalPrincipalDerechaIzquierda = "Los valores de la diagonal principal derecha a izquierda son: ";
        for (int fila = 0; fila < matriz.length; fila++) {
            diagonalPrincipalDerechaIzquierda += matriz[matriz.length - 1 - fila][matriz.length - 1 - fila] + "\t";

        }

        return diagonalPrincipalDerechaIzquierda;
    }

    public String getDiagonalSecundariaDerechaIzquierda() {


        String diagonalSecundariaDerechaIzquierda = "Los valores de la diagonal secundaria derecha a izquierda son: ";
        for (int fila = 0; fila < matriz.length; fila++) {
            diagonalSecundariaDerechaIzquierda += matriz[matriz.length - 1 - fila][fila] + "\t";
        }

        return diagonalSecundariaDerechaIzquierda;

    }

    private int getSuma() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getPromedioFila() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

    

    

   
