/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miprimerinterfaz.view;

/**
 *
 * @author UCR
 */

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author UCR
 */
public class PanelDibujo extends JPanel {
    
    private int x;
    private int y;
    
   
    public PanelDibujo(){
        
        x=20;
        y=20;
        setBackground(Color.pink);
       
    }
    
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    g.fillOval(x, y, 40, 40);
    
    }
    
    public void moveUp(){
    y-=10;
}
    
    public void moveDown(){
    y+=10;
    }
    
    public void moveLeft(){
        x-=10;
    }
    
    public void moveRight(){
    x+=10;
    }
}