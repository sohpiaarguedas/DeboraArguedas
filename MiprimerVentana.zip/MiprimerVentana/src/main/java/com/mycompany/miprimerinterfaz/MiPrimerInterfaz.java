/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miprimerinterfaz;

import com.mycompany.miprimerinterfaz.controller.Controller;



 
 
public class MiPrimerInterfaz {

    public static void main(String[] args) {
       
       //Ventana miVentana = new Ventana();
       Controller controller=new Controller();
       
    }

   
}