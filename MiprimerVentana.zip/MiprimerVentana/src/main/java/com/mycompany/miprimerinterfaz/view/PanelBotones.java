/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miprimerinterfaz.view;

import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;


public class PanelBotones extends JPanel {
    private JButton btnUp;
    private JButton btnDown;
    private JButton btnLeft;
    private JButton btnRight;
    
    public PanelBotones(){
        btnUp = new JButton("Arriba");
        add(btnUp);
        btnDown=new JButton("Abajo");
        add(btnDown);
        btnLeft=new JButton("Izquierda");
        add(btnLeft);
        btnRight=new JButton("Derecha");
        add(btnRight);
        
        setBackground( Color.darkGray);
    }

        public void escuchar(ActionListener controller){
            
            btnUp.addActionListener(controller);
            btnDown.addActionListener(controller);
            btnLeft.addActionListener(controller);
            btnRight.addActionListener(controller);
        }
    
}

