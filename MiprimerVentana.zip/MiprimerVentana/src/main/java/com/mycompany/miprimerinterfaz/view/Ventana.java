/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miprimerinterfaz.view;


import java.awt.BorderLayout;
import javax.swing.JFrame;
public class Ventana extends JFrame {
    
    private PanelDibujo panelDibujo;
    private PanelBotones panelBotones;
    
    public Ventana(){
    super("Mi ventana");
    panelDibujo=new PanelDibujo();
    panelBotones=new PanelBotones();
    add(panelDibujo,BorderLayout.CENTER);
    add(panelBotones,BorderLayout.SOUTH);
    
    
    setSize(600,600);
        setDefaultCloseOperation(3);
    
    setVisible(true);
    }
    
    public PanelBotones getPanelBotones(){
    return panelBotones;
    }
    
     public PanelDibujo getPanelDibujo(){
    return panelDibujo;
    }
}
   

   

    
   