/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.miprimerinterfaz.controller;

import com.mycompany.miprimerinterfaz.view.PanelBotones;
import com.mycompany.miprimerinterfaz.view.PanelDibujo;
import com.mycompany.miprimerinterfaz.view.Ventana;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author UCR
 */
public class Controller implements ActionListener{
    private Ventana miVentana;
    private PanelBotones panelBotones;
    private PanelDibujo panelDibujo;
    
    public Controller(){
        
    miVentana=new Ventana();
    panelBotones=miVentana.getPanelBotones();
    panelDibujo=miVentana.getPanelDibujo();
    panelBotones.escuchar(this);
    
         }
 
    
    @Override
    public void actionPerformed(ActionEvent evento){
    switch(evento.getActionCommand()){
        case "Arriba":
            panelDibujo.moveUp();
            System.out.println("Presiono el boton de arriba");
            break;
            
        case "Abajo":
            panelDibujo.moveDown();
            System.out.println("Presiono el boton de abajo");
            break;
            
        case "Izquierda":
            panelDibujo.moveLeft();
            System.out.println("Presiono el boton de la izquierda");
            break;
            
        case "Derecha":
            panelDibujo.moveRight();
            System.out.println("Presiono el boton de la derecha");
            break;
            
    }
    panelDibujo.repaint();
    
    
    }
    
}
