/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movertexto;

import com.mycompany.movertexto.controlador.Controlador;


/**
 *
 * @author Usuario
 */
public class MoverTexto {

    public static void main(String[] args) {
    // VentanaT ventanaT;
     //ventanaT= new VentanaT();
     Controlador controlador=new Controlador();
    }
}
