/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.movertexto.controlador;

import com.mycompany.movertexto.view.PanelB;
import com.mycompany.movertexto.view.PanelD;
import com.mycompany.movertexto.view.VentanaT;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Usuario
 */
public class Controlador implements ActionListener{
    
   private VentanaT ventanaTexto;
   private PanelB panelB;
   private PanelD panelD;
   
   public Controlador(){
   ventanaTexto=new VentanaT();
   panelB=ventanaTexto.getPanelB();
    panelD=ventanaTexto.getPanelD();
   panelB.escuchar(this);
   }
   
      
    @Override
    public void actionPerformed(ActionEvent evento){
    switch(evento.getActionCommand()){
        case "Arriba":
            panelD.moveUp();
            System.out.println("Presiono el boton de arriba");
            break;
            
        case "Abajo":
            panelD.moveDown();
            System.out.println("Presiono el boton de abajo");
            break;
            
        case "Izquierda":
            panelD.moveLeft();
            System.out.println("Presiono el boton de la izquierda");
            break;
            
        case "Derecha":
            panelD.moveRight();
            System.out.println("Presiono el boton de la derecha");
            break;
            
    }
    panelD.repaint();
    }
   
}
