/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.movertexto.view;

import java.awt.BorderLayout;
import javax.swing.JFrame;

/**
 *
 * @author Usuario
 */
public class VentanaT extends JFrame{
   private PanelD panelD;
   private PanelB panelB;
   
   public VentanaT(){
   
   super("Ventanita");
   panelD=new PanelD();
   panelB=new PanelB();
   
   add(panelD, BorderLayout.CENTER);
   add(panelB, BorderLayout.SOUTH);
   
   setSize(400,500);
    setDefaultCloseOperation(3);
   setVisible(true);
   
   }
   
    public PanelB getPanelB(){
    return panelB;
    }
    
     public PanelD getPanelD(){
    return panelD;

   
}

  
}
