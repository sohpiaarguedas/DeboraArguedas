/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.movertexto.view;

import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Usuario
 */
public class PanelB extends JPanel{
    private JButton btnUp;
    private JButton btnDown;
    private JButton btnRight;
    private JButton btnLeft;
    
    public PanelB(){
        btnUp = new JButton("Arriba");
        add(btnUp);
        btnDown=new JButton("Abajo");
        add(btnDown);
        btnLeft=new JButton("Izquierda");
        add(btnLeft);
        btnRight=new JButton("Derecha");
        add(btnRight);
        
        setBackground( Color.LIGHT_GRAY);
    }
    
    public void escuchar(ActionListener controlador){
            
            btnUp.addActionListener(controlador);
            btnDown.addActionListener(controlador);
            btnLeft.addActionListener(controlador);
            btnRight.addActionListener(controlador);
        }
    
    
}
