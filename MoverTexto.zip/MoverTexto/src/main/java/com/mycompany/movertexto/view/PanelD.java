/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.movertexto.view;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author Usuario
 */
public class PanelD extends JPanel{
    private int y;
    private int x;
    
    public PanelD(){
    y=10;
    x=15;
    setBackground(Color.ORANGE);
    
    }
    
     public void paintComponent(Graphics g){
    super.paintComponent(g);
    g.drawString("Hola", x, y);
    }
     
    public void moveUp(){
    y-=10;
}
    
    public void moveDown(){
    y+=10;
    }
    
    public void moveLeft(){
        x-=10;
    }
    
    public void moveRight(){
    x+=10;
    }
}
